Example de model counting pour le script verifPin.c dans le répertoire verifPin
	klee-out-1 répertoire fourni par klee
	fncf1 est la conversion des fichiers .smt2 en format cnf (fourni par stp)
	modelModel0.txt est le nombre de model de chaque fichier .cnf écrit un par ligne (fourni par approxmc)

Le script automatisation.sh prend en argument un repertoire klee-out-N et génère un répertoire fcnfN et un fichier nbModelN.txt
Le script auto_stp.sh prend en argument un klee-out-N et génère un répertoire fncfN
Le script script_approxmc.sh permet d'executer approxmc en une seule commande (./script_approxmc.sh $1 au lieux de cat $1 | docker run --rm -i -a stdin -a stdout msoos/approxmc)
Le script auto_approxmc.sh prend en argument un repertoire de fichiers .cnf et fournit un fichier nbModel<nom du répertoire>.txt contenant le nombre de model de chaque fichier .cnf écrit 1 par ligne