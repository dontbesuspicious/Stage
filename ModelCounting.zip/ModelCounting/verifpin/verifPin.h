#ifndef VERIFYPIN_H
#define VERIFYPIN_H

typedef unsigned char UBYTE;
typedef unsigned char BOOL;

#define BOOL_TRUE 0xAA
#define BOOL_FALSE 0x55

#define PIN_SIZE 4

extern UBYTE g_authenticated;
extern UBYTE g_ptc;
extern UBYTE g_userPin[PIN_SIZE];
extern UBYTE g_cardPin[PIN_SIZE];


BOOL verifyPIN();

#endif