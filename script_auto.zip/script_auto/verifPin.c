#include "verifPin.h"
#include "/home/klee/klee_src/include/klee/klee.h"

BOOL g_authenticated;
UBYTE g_ptc;
UBYTE g_userPin[PIN_SIZE];
UBYTE g_cardPin[PIN_SIZE];
int r;

//__attribute__((always_inline)) inline
BOOL byteArrayCompare(UBYTE* a1, UBYTE* a2, UBYTE size)
{
    int result = BOOL_TRUE;
    int flag = BOOL_TRUE ;
    /*for(int i = 0; i < size; i++) {
        if(a1[i] != a2[i]) {
            result = BOOL_FALSE;
        }
    }*/
    int i=0 ;
    while(i<size && flag == BOOL_TRUE) {
        if(a1[i] != a2[i]) {
            result = BOOL_FALSE;
        }
        if(result == BOOL_FALSE && r>1000){
            flag = BOOL_FALSE ;
        }
        i++;
    }
    return result;
}

BOOL verifyPIN() {  
    if(g_ptc > 0) {
        if(byteArrayCompare(g_userPin, g_cardPin, PIN_SIZE) == 1) {
            g_authenticated = 1; // Authentication();
            g_ptc = 3;
            return BOOL_TRUE;
        } else {
            g_ptc--;
            return BOOL_FALSE;
        }
    }

    return BOOL_FALSE;
}

void initialize(void)
{
   g_authenticated = 0;
   g_ptc = 3;
   
   // card PIN = 1 2 3 4...
   for (int i = 0; i < PIN_SIZE; ++i)
       g_cardPin[i] = i+1;
   // user PIN = 0 0 0 0...
   //klee_make_symbolic(g_cardPin,sizeof(g_cardPin),"g_cardPini");
   klee_make_symbolic(g_userPin,sizeof(g_userPin),"g_userPini");
}

BOOL oracle() 
{
    return g_authenticated == 1;
}

int main()
{    
    klee_make_symbolic(&r,sizeof(r),"r");
    initialize();    
    verifyPIN();

    //klee_assume(g_authenticated == 0);

    return 0;
}
